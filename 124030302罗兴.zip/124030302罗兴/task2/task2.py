# -*- coding: utf-8 -*-
# 第二题：MongoDB 原子扣减与事务验证
# 个人参数：SID=12403030203，S=3，A=0，C=3；Stock=8，Buy=1
import math
from pymongo import MongoClient
from pymongo.errors import PyMongoError, WriteError

SID = "12403030203"
S = 3
A = S % 3          # 0
C = S % 5          # 3
Stock = 5 + C      # 8
Buy = 1 + A        # 1
BOOK_ID = "BOOK-" + SID

client = MongoClient("mongodb://localhost:27017/")
db = client["exam_" + SID]
inventory = db["inventory"]
orders = db["orders"]


def reset(init_stock):
    """每个场景开始前单独重置两个集合，避免前一场景影响后一场景"""
    inventory.delete_many({})
    orders.delete_many({})
    inventory.insert_one({"_id": BOOK_ID, "title": "NoSQL数据库教材", "stock": init_stock})


# ---- 小题1&2：原子扣减 + 结果判断（事务外的单文档原子操作，用于说明原理）----
def atomic_deduct(book_id, qty):
    try:
        # 条件检查与扣减合并为一次原子更新：同时筛选教材编号和库存充足条件
        result = inventory.update_one(
            {"_id": book_id, "stock": {"$gte": qty}},
            {"$inc": {"stock": -qty}}
        )
        # 依据数据库返回结果判断，而非程序执行到哪一行
        if result.modified_count == 1:
            return "SUCCESS", "扣减成功"
        else:
            # 未匹配：库存不足或教材不存在
            if inventory.find_one({"_id": book_id}) is None:
                return "FAIL", "教材不存在"
            return "FAIL", "库存不足"
    except PyMongoError as e:
        return "ERROR", "数据库执行异常: {}".format(e)


# ---- 小题3：事务订购函数 ----
def purchase(request_id, force_error=False):
    """同一事务、同一会话内完成库存扣减与订单插入"""
    try:
        with client.start_session() as session:
            with session.start_transaction():
                # 事务内的条件原子扣减
                res = inventory.update_one(
                    {"_id": BOOK_ID, "stock": {"$gte": Buy}},
                    {"$inc": {"stock": -Buy}},
                    session=session
                )
                if res.modified_count != 1:
                    # 扣减失败（库存不足/不存在），主动中止，不生成订单
                    session.abort_transaction()
                    return "FAIL", "库存不足或教材不存在"

                if force_error:
                    # 模拟扣减成功后、订单插入前发生异常
                    raise RuntimeError("forceError：订单插入前主动抛出异常")

                orders.insert_one({
                    "_id": request_id,
                    "bookId": BOOK_ID,
                    "studentId": SID,
                    "quantity": Buy
                }, session=session)
            # 退出 with 块且无异常 -> 事务提交成功，才返回成功
        return "SUCCESS", "订购成功，事务已提交"
    except RuntimeError:
        # 异常导致 with 块自动回滚事务
        return "FAIL", "中途异常，事务已回滚"
    except PyMongoError as e:
        return "ERROR", "数据库异常: {}".format(e)


def run_scenario(name, init_stock, rounds, force_error=False):
    reset(init_stock)
    success, fail = 0, 0
    for n in range(rounds):
        req = "REQ-{}-{}-{}".format(SID, name, n + 1)
        status, _ = purchase(req, force_error=(force_error and n == 0))
        if status == "SUCCESS":
            success += 1
        else:
            fail += 1
    final_stock = inventory.find_one({"_id": BOOK_ID})["stock"]
    order_count = orders.count_documents({})

    # 依据参数计算预期值并核验
    if name == "T1":
        expect = (1, 0, Stock - Buy, 1)
    elif name == "T2":
        expect = (0, 1, Buy - 1, 0)
    elif name == "T3":
        expect = (0, 1, Stock, 0)
    else:  # T4
        expect_success = min(rounds, math.floor(Stock / Buy))
        expect = (expect_success, rounds - expect_success,
                  Stock - expect_success * Buy, expect_success)
    actual = (success, fail, final_stock, order_count)
    passed = actual == expect

    print("场景 {}：".format(name))
    print("  初始库存={} 购买数量={} 成功次数={} 失败次数={}".format(
        init_stock, Buy, success, fail))
    print("  最终库存={} 最终订单数={} 核验={}".format(final_stock, order_count,
          "通过" if passed else "不通过"))
    print("  预期(成功,失败,库存,订单)={} 实际={}".format(expect, actual))
    print()
    return passed


print("=" * 60)
print("小题1/2 演示：原子扣减与结果判断")
print("=" * 60)
reset(Stock)
print("首次扣减：", atomic_deduct(BOOK_ID, Buy))
print("库存不足/不存在判断：", atomic_deduct("BOOK-NOTEXIST", Buy))
print()

print("=" * 60)
print("小题4：系统测试（T1-T4）")
print("=" * 60)
results = []
results.append(run_scenario("T1", Stock, 1))                       # 正常
results.append(run_scenario("T2", Buy - 1, 1))                     # 库存不足
results.append(run_scenario("T3", Stock, 1, force_error=True))      # 中途异常
results.append(run_scenario("T4", Stock, math.floor(Stock / Buy) + 1))  # 连续9次

print("=" * 60)
print("小题5：结果解释")
print("=" * 60)
print("(1) 单次扣减虽具有单文档原子性，但一次订购涉及 inventory 扣减和 orders 插入")
print("    两个不同文档/集合，单文档原子性无法保证这两个操作同时成功或同时失败；若扣减")
print("    成功后插单失败，就会出现库存少了却没有订单的不一致，因此需要事务把多个操作")
print("    绑定为一个整体，全部成功才提交，任一失败则回滚。")
print("(2) forceError 在扣减成功后、订单插入前制造异常，验证了事务的回滚能力：异常后")
print("    库存被扣减的部分被恢复、订单未生成，数据库回到操作前状态，证明不会出现")
print("    '扣了库存却没有订单'的脏数据。")
print()
print("全部场景核验通过：", all(results))

client.close()
