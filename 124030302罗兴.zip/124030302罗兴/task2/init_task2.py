# -*- coding: utf-8 -*-
# 第二题初始化脚本：重置 inventory 与 orders 两个集合（与业务操作分开）
from pymongo import MongoClient

SID = "12403030203"
C = 3
Stock = 5 + C  # =8

client = MongoClient("mongodb://localhost:27017/")
db = client["exam_" + SID]

db.inventory.delete_many({})
db.orders.delete_many({})
db.inventory.insert_one({
    "_id": "BOOK-" + SID,
    "title": "NoSQL数据库教材",
    "stock": Stock
})
print("初始化完成，库存：", db.inventory.find_one({}, {"_id": 1, "stock": 1}))
client.close()
