# -*- coding: utf-8 -*-
# 第三题：Redis 学习信息与排行榜（三主三从 Redis Cluster，端口30203-30208）
# 个人参数：SID=12403030203，C=3；所有键统一前缀 exam:12403030203:
import time
from redis.cluster import RedisCluster
from redis.exceptions import RedisError

SID = "12403030203"
C = 3
P = "exam:{}:".format(SID)

r = RedisCluster(host="127.0.0.1", port=30203, decode_responses=True, protocol=2)

# 清理本前缀的历史数据，保证可重复运行
for key in r.scan_iter(match=P + "*"):
    r.delete(key)

print("=" * 60)
print("小题1：学生信息维护（Hash）")
print("=" * 60)
hash_key = P + "student"
r.hset(hash_key, mapping={
    "studentId": SID,
    "name": "张三",
    "className": "计算机2403班",
    "courseId": "COURSE-{}-01".format(SID),
    "status": "learning"
})
r.hset(hash_key, "status", "completed")  # 单独修改 status
print("单独读取 name =", r.hget(hash_key, "name"))
print("单独读取 status =", r.hget(hash_key, "status"))
print("完整 Hash：", r.hgetall(hash_key))

print()
print("=" * 60)
print("小题2：已完成章节记录（Set）")
print("=" * 60)
set_key = P + "chapters"
for ch in ("CH01", "CH02", "CH02", "CH03"):
    r.sadd(set_key, ch)  # 重复成员自动去重
    print("提交 {} 后，已完成章节数量 = {}".format(ch, r.scard(set_key)))
print("最终全部章节：", r.smembers(set_key))
print("CH02 是否完成：", r.sismember(set_key, "CH02"))
print("CH04 是否完成：", r.sismember(set_key, "CH04"))
r.sadd(set_key, "CH02")
print("再次重复提交 CH02 后数量仍为：", r.scard(set_key), "（不增加）")

print()
print("=" * 60)
print("小题3：成绩排行榜（Sorted Set）")
print("=" * 60)
zset_key = P + "ranking"
me = "Student:{}".format(SID)
r.zadd(zset_key, {
    me: 70 + C,       # 73
    "demo:01": 85,
    "demo:02": 90,
    "demo:03": 60,
    "demo:04": 80
})
def show_top3(tag):
    print(tag)
    for rank, (member, score) in enumerate(
            r.zrevrange(zset_key, 0, 2, withscores=True), start=1):
        print("  第{}名：{} = {}分".format(rank, member, int(score)))
show_top3("更新前 前3名：")
r.zincrby(zset_key, 20, me)  # 本人加20分 -> 93
show_top3("加20分后 前3名：")
my_score = r.zscore(zset_key, me)
# 降序名次：比本人分数高的人数 + 1
my_rank = r.zcount(zset_key, my_score + 1, "+inf") + 1
print("本人更新后分数 = {}，名次 = 第{}名".format(int(my_score), my_rank))

print()
print("=" * 60)
print("小题4：会话生命周期（String + TTL）")
print("=" * 60)
sess_key = P + "session"
r.set(sess_key, "session-token-{}".format(SID), ex=5)
print("创建后立即读取：值 =", r.get(sess_key), " TTL =", r.ttl(sess_key), "秒")
session_type_before_expire = r.type(sess_key)  # 在过期前记录数据类型
print("等待 6 秒...")
time.sleep(6)
exists = r.exists(sess_key)
print("6秒后 键是否存在 =", bool(exists), " TTL =", r.ttl(sess_key))
print("过期验证：", "通过（键已自动过期）" if not exists else "不通过")

print()
print("=" * 60)
print("小题5：数据类型核验与说明")
print("=" * 60)
for key, label in [
    (hash_key, "学生信息"),
    (set_key, "章节集合"),
    (zset_key, "成绩排行榜")
]:
    print("{} -> 实际类型: {}".format(label, r.type(key)))
print("会话 -> 实际类型(过期前检查): {}".format(session_type_before_expire))
print()
print("选择理由：")
print("  Hash：学生信息是多个字段-值的映射，Hash 可按字段单独读写而不必整体序列化。")
print("  Set：章节只关心是否完成且天然去重，sadd 重复提交不会产生重复成员。")
print("  Sorted Set：排行榜需要按分数排序并查询名次，成员自带可排序的分值。")
print("  String：会话标识是单个带过期时间的值，String+TTL 最直接地表达键值与生命周期。")

r.close()
