# -*- coding: utf-8 -*-
# 第一题初始化脚本：建立 courses 集合并写入初始数据（与业务操作分开）
# 仅在需要重置数据时运行，业务操作重复验证时不再运行本脚本
from pymongo import MongoClient

SID = "12403030203"

client = MongoClient("mongodb://localhost:27017/")
examDB = client["exam_" + SID]

examDB.courses.delete_many({})
examDB.courses.insert_many([
    {
        "_id": "COURSE-" + SID + "-01",
        "title": "NoSQL数据库",
        "teacher": "张老师",
        "status": "OPEN",
        "chapters": [
            {"chapterId": "CH01", "title": "MongoDB基础", "hours": 2},
            {"chapterId": "CH02", "title": "Redis基础", "hours": 2}
        ]
    },
    {
        "_id": "COURSE-" + SID + "-02",
        "title": "数据库原理",
        "teacher": "张老师",
        "status": "CLOSED",
        "chapters": [
            {"chapterId": "CH01", "title": "关系模型", "hours": 2}
        ]
    },
    {
        "_id": "COURSE-" + SID + "-03",
        "title": "机器学习",
        "teacher": "李老师",
        "status": "OPEN",
        "chapters": [
            {"chapterId": "CH01", "title": "分类", "hours": 2},
            {"chapterId": "CH02", "title": "聚类", "hours": 2}
        ]
    }
])
print("初始化完成，courses 文档数：", examDB.courses.count_documents({}))
client.close()
