# -*- coding: utf-8 -*-
# 第一题业务脚本：MongoDB 课程信息查询与维护
# 个人参数：SID=12403030203，S=3，A=0
from pymongo import MongoClient
from pymongo.errors import PyMongoError

SID = "12403030203"
S = 3
A = S % 3  # =0

client = MongoClient("mongodb://localhost:27017/")
courses = client["exam_" + SID]["courses"]
COURSE01 = "COURSE-" + SID + "-01"

print("=" * 60)
print("小题1：查询张老师授课且状态为 OPEN 的课程")
print("=" * 60)
# 章节数量用聚合表达式 $size 依据数据库中的 chapters 数组实时计算，不写死
pipeline = [
    {"$match": {"teacher": "张老师", "status": "OPEN"}},
    {"$project": {
        "_id": 1,
        "title": 1,
        "chapterCount": {"$size": "$chapters"}
    }}
]
for doc in courses.aggregate(pipeline):
    print("课程编号：{} | 课程名称：{} | 章节数量：{}".format(
        doc["_id"], doc["title"], doc["chapterCount"]))

print()
print("=" * 60)
print("小题2：局部更新第01门课程 CH02 的标题")
print("=" * 60)
new_title = "Redis基础与应用-{}".format(S)
# 使用 $set + 数组位置定位符 $ 做局部更新，只改匹配章节的 title，其他字段/章节原样保留
res = courses.update_one(
    {"_id": COURSE01, "chapters.chapterId": "CH02"},
    {"$set": {"chapters.$.title": new_title}}
)
print("匹配文档数：{}，实际修改文档数：{}".format(res.matched_count, res.modified_count))
print("更新后的课程文档：")
print(courses.find_one({"_id": COURSE01}))

print()
print("=" * 60)
print("小题3：增加 CH03 章节并防止重复（连续执行两次）")
print("=" * 60)
new_chapter = {"chapterId": "CH03", "title": "Redis高级操作", "hours": 2 + A}
for i in (1, 2):
    # 过滤条件中要求该文档不存在 chapterId=CH03 的章节；
    # 已存在时 update 不匹配任何文档，$push 不执行，从而保证顺序重复执行只出现一次。
    # 不先删除、不读取整个文档在客户端拼接替换。
    r = courses.update_one(
        {"_id": COURSE01, "chapters.chapterId": {"$ne": "CH03"}},
        {"$push": {"chapters": new_chapter}}
    )
    print("第{}次执行：匹配{}，修改{}".format(i, r.matched_count, r.modified_count))

print()
print("=" * 60)
print("小题4：验证与解释")
print("=" * 60)
final = courses.find_one({"_id": COURSE01})
ch02 = next(c for c in final["chapters"] if c["chapterId"] == "CH02")
ch03_count = sum(1 for c in final["chapters"] if c["chapterId"] == "CH03")
print("(1) 修改后 CH02 的标题：", ch02["title"])
print("(2) 两次新增后 CH03 的数量：", ch03_count)
print("(3) 最终章节总数：", len(final["chapters"]))
print("(4) teacher = {}（原值张老师），status = {}（原值OPEN）".format(
    final["teacher"], final["status"]))
print("    字段保持原值：", final["teacher"] == "张老师" and final["status"] == "OPEN")
print()
print("说明：本题只修改数组中的个别元素，局部更新（$set/$push）只把变化的字段发送到")
print("服务器，网络传输量小，且能天然保留其他字段和章节，避免并发覆盖；若直接替换整个")
print("文档，需要先读出完整文档再整体写回，既容易在写回时覆盖他人的并发修改，也会产生")
print("额外的读写开销，因此本题适合局部更新而不宜整体替换。")

client.close()
