# -*- coding: utf-8 -*-
# 第四题（选做）：Redis 逐条写入 vs 普通 Pipeline 写入性能比较
# 个人参数：SID=12403030203，S=3，C=3；N=1303，Q=100
import math
import time
from redis.cluster import RedisCluster

SID = "12403030203"
S = 3
C = 3
N = 1000 + 100 * C + S   # 1303
Q = 100
P = "exam:{}:".format(SID)

r = RedisCluster(host="127.0.0.1", port=30203, decode_responses=True, protocol=2)

# 清理两种方案的历史键
for key in r.scan_iter(match=P + "seq:*"):
    r.delete(key)
for key in r.scan_iter(match=P + "pipe:*"):
    r.delete(key)

# ---- 方案甲：逐条写入，每条收到返回后再发下一条，不用 Pipeline/多线程/异步 ----
start = time.perf_counter()
for i in range(1, N + 1):
    r.set("{}seq:{}".format(P, i), "value-{}-{}".format(SID, i))
ms_a = (time.perf_counter() - start) * 1000

# ---- 方案乙：普通非事务 Pipeline，每批最多 Q 条，处理最后不足 Q 的尾批 ----
start = time.perf_counter()
batch_count = 0
for begin in range(1, N + 1, Q):
    end = min(begin + Q - 1, N)
    pipe = r.pipeline(transaction=False)   # 显式非事务型 Pipeline
    for i in range(begin, end + 1):
        pipe.set("{}pipe:{}".format(P, i), "value-{}-{}".format(SID, i))
    pipe.execute()                         # 收到整批回复后再提交下一批
    batch_count += 1
ms_b = (time.perf_counter() - start) * 1000

# ---- 数据完整性核验 ----
seq_ok = all(r.get("{}seq:{}".format(P, i)) == "value-{}-{}".format(SID, i)
             for i in range(1, N + 1))
pipe_ok = all(r.get("{}pipe:{}".format(P, i)) == "value-{}-{}".format(SID, i)
              for i in range(1, N + 1))
last_batch_size = N - (batch_count - 1) * Q

print("=" * 60)
print("第四题：Pipeline 与性能比较")
print("=" * 60)
print("命令总数 N =", N)
print("每批上限 Q =", Q)
print("Pipeline 批次数 =", batch_count)
print("最后一批数量 =", last_batch_size)
print("方案甲（逐条）耗时 = {} ms".format(round(ms_a, 2)))
print("方案乙（Pipeline）耗时 = {} ms".format(round(ms_b, 2)))
print("加速比 = {} 倍".format(round(ms_a / ms_b, 2) if ms_b else "N/A"))
print("方案甲数据完整 =", seq_ok)
print("方案乙数据完整 =", pipe_ok)
print("尾批处理正确（最后一批{}条，编号{}~{}）= {}".format(
    last_batch_size, N - last_batch_size + 1, N, last_batch_size == 3))
print()
if ms_b < ms_a:
    print("结论：普通 Pipeline 更快。它把多条命令一次性发送、再批量读取回复，大幅减少了")
    print("网络往返次数（逐条方式有 N 次往返，Pipeline 只有约 N/Q 次）。")
else:
    print("结论：本次 Pipeline 未明显更快或更慢。可能原因：本机回环地址网络延迟本就极低，")
    print("往返开销小；Pipeline 有缓冲与批量打包成本；数据量偏小；或客户端/集群对命令的")
    print("路由处理带来额外开销。在真实网络（高延迟、跨机房）环境下 Pipeline 优势会更明显。")

r.close()
