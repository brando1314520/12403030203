《NoSQL数据库》上机测验 —— 源代码与运行结果说明
====================================================

一、个人信息
  学号 SID：12403030203
  姓名：罗兴（源代码中涉及个人姓名处按要求统一以“张三”代替）
  班级：计算机2403班（如与实际不符，请在 task3/task3.py 中修改 className）

二、个人参数（学号最后两位为 03）
  S = 3
  A = S mod 3 = 0
  B = S mod 4 = 3
  C = S mod 5 = 3
  MongoDB 个人数据库：exam_12403030203
  Redis 键统一前缀：exam:12403030203:
  第二题：Stock = 5 + C = 8，Buy = 1 + A = 1
  第四题：N = 1000 + 100C + S = 1303，Q = 100（共14批，尾批3条）

三、运行环境
  操作系统：Windows 11 家庭中文版
  MongoDB：8.3.11（已配置为单节点副本集 rs0 以支持事务，端口 27017）
  Redis：三主三从 Redis Cluster（端口 30203-30208，主节点 30203/30204/30205）
  Python：3.13
  依赖库：pymongo 4.19.0、redis-py 8.1.0
  安装依赖：python -m pip install pymongo redis

四、目录结构与各题执行方法
  task1/  第一题 MongoDB 课程信息查询与维护
          init_task1.py  初始化 courses 集合（仅重置数据时运行）
          task1.py       业务操作（查询/局部更新/防重复新增/验证）
          result_task1.txt 运行结果
  task2/  第二题 MongoDB 原子扣减与事务
          init_task2.py  初始化 inventory/orders
          task2.py       原子扣减、事务、T1-T4 测试
          result_task2.txt 运行结果
  task3/  第三题 Redis 学习信息与排行榜
          task3.py       Hash/Set/Sorted Set/String 全部操作
          result_task3.txt 运行结果
  task4/  第四题（选做）Redis Pipeline 性能比较
          task4.py       逐条 vs Pipeline 计时与完整性核验
          result_task4.txt 运行结果

  执行顺序（在各题目录下）：
    先运行初始化脚本（task1、task2）：python init_taskX.py
    再运行业务脚本：python taskX.py
  说明：初始化代码与业务操作代码已分开；业务重复验证时无需重新初始化。

五、结果摘要
  第一题：查询、局部更新（CH02 标题改为 Redis基础与应用-3）、CH03 防重复、字段保留均通过。
  第二题：T1/T2/T3/T4 四个场景全部核验通过；forceError 验证事务回滚成功。
  第三题：Hash/Set/ZSet/String 功能正确；本人成绩 73+20=93 分，升至第1名；会话5秒过期。
  第四题：逐条 284.23ms，Pipeline 37.12ms，加速约 7.66 倍，1303 条数据完整、尾批3条正确。

六、注意事项
  1. 源代码未包含任何数据库账号密码等连接凭据（本地无认证连接）。
  2. 运行 Redis 题目前需先启动 30203-30208 六个集群节点。
  3. 运行第二题事务前需确保 MongoDB 已处于副本集 rs0 状态。
  4. 结果截图请按各题实际运行界面另行截取后粘贴到实验报告。
